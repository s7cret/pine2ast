# Compile oracle metadata

Pine2AST does not call TradingView or any network service from the CLI. Compile-oracle fixtures are a manually checked evidence layer for Pine cases where TradingView behaviour matters for production sign-off.

## Metadata format

Each oracle category stores a `metadata.json` next to its `.pine` fixtures:

```json
{
  "schema_version": 2,
  "pine_version": 6,
  "checked_at": "2026-04-27",
  "oracle": "internal pine2ast semantic policy checked; external TradingView compile oracle still required for final production sign-off",
  "policy": [
    {
      "fixture": "strategy_closedtrades_allowed.pine",
      "context": "strategy",
      "usage": "strategy.closedtrades.entry_price/comment",
      "expected": "allowed",
      "pine2ast_status": "pass",
      "tradingview_status": "pending_external_oracle"
    }
  ]
}
```

`tradingview_status` values:

- `pass` — manually compiled successfully in TradingView Pine Editor.
- `fail_expected` — manually failed in TradingView with the expected policy/semantic error.
- `pending_external_oracle` — not manually checked yet. This is allowed in development, but blocks production sign-off.

Do not invent TradingView statuses. If no Pine Editor access is available, leave `pending_external_oracle` and let the report fail explicitly.

## Report command

```bash
python tools/compile_oracle_report.py \
  --path tests/fixtures/compile_oracle \
  --json COMPILE_ORACLE_v2_15_0.json
```

Exit codes:

- `0` — all metadata is valid and no P0 fixture is pending.
- `1` — metadata is structurally valid but at least one fixture is still `pending_external_oracle`.
- `2` — invalid metadata or missing fixture file.

For local evidence snapshots before manual TradingView sign-off:

```bash
python tools/compile_oracle_report.py \
  --path tests/fixtures/compile_oracle \
  --json COMPILE_ORACLE_v2_15_0.json \
  --allow-pending
```
