# Builtin registry notes

`pine2ast/semantic/builtins_v6.json` is a versioned Pine v6 builtin snapshot used by semantic analysis. It is intentionally not a claim of complete TradingView/Pine official API coverage.

## Schema validation

`load_builtin_registry()` validates the JSON before exposing it. The validator checks required top-level sections, function entry identity, required function fields, parameter array shape, duplicate parameter names, variable type/qualifier shape, supported scopes/kinds, and version fields.

Use `validate_builtin_registry(registry)` in tests for corrupt or generated registry payloads.

## Coverage taxonomy

`builtin_registry_coverage_report()` separates coverage into explicit buckets:

- `internal_expected` / `missing_internal_expected`: curated project confidence set. Missing entries are actionable regressions/backlog.
- `official_unmapped`: known official Pine members not yet modeled in `builtins_v6.json`. These do not make internal coverage fail.
- `known_deferred`: known official or quasi-official surface intentionally deferred.
- `known_unsupported`: known surface intentionally unsupported by this parser/semantic layer.

The report keeps legacy fields (`expected_count`, `missing_expected`, `coverage_ratio`) as aliases for the internal expected snapshot only. A green `missing_expected=[]` means the project snapshot is closed; it does **not** mean official Pine builtin coverage is complete.
