# Optimizer / AST2Python inspect contract

`pine2ast inspect` emits the stable integration payload for downstream optimizer and AST2Python consumers.

```bash
python -m pine2ast inspect tests/fixtures/inspect_contract/optimizer_strategy.pine --json inspect.json
```

Contract fields:

- `schema_version`: currently `1`.
- `contract`: `pine2ast.inspect.optimizer.v1`.
- `tool`: producer name and package version.
- `source.path`: caller-provided path, for traceability only.
- `ok` and `diagnostics`: parser/semantic status.
- `inputs`: extracted `input.*` declarations with literal defaults/ranges/options.
- `strategy_calls`, `request_calls`, `plots`, `alerts`, `drawings`: downstream-relevant calls with `name`, `arg_count`, and source span.
- `dependencies`: imports, aliases, namespaces, builtin calls, user calls, methods, UDT constructors, external calls and unknown calls.

Committed contract fixture:

- Source: `tests/fixtures/inspect_contract/optimizer_strategy.pine`
- Expected JSON: `tests/fixtures/inspect_contract/optimizer_strategy.inspect.json`

The fixture is intentionally small but covers strategy, inputs, request, alert, drawing, external import call and plot extraction.
