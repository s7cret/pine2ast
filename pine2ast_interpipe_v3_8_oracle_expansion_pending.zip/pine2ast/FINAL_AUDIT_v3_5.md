# Final Audit v3.5 / package 0.3.5

## Scope

v3.5 is a behavior-preserving parser modularization release. It starts from committed v3.4 hardening commit `6cebab5` and separates parser implementation into focused modules without changing the AST schema or Pine grammar policy.

## Implementation summary

- `pine2ast/parser/parser.py` is now a thin public facade.
- `pine2ast/parser/base.py` owns parser state, orchestration, diagnostics, token helpers, recovery, lookahead predicates, `ParserResult`, and `join_span`.
- `pine2ast/parser/expressions.py` owns expression parsing.
- `pine2ast/parser/statements.py` owns statements, blocks, loops, switches, conditionals, and function bodies.
- `pine2ast/parser/declarations.py` owns imports, type/enum/function/method declarations, parameters, and type references.
- Public import compatibility is covered by `tests/unit/test_parser_module_boundaries.py`.

## Compatibility assertions

- No AST schema changes were made.
- Golden AST fixtures were not regenerated or changed.
- Optimizer inspect JSON snapshots changed only in tool/producer version metadata (`0.3.4` → `0.3.5`) to match the package release version.
- Pine block braces `{}` remain unsupported.
- `expr[n]` remains `HistoryRefExpr`, not array indexing.
- `input` is not treated as a declaration qualifier.
- Semantic checks remain in semantic layers, not parser modules.

## Oracle evidence

The release preserves the existing v3.3/v3.4 TradingView evidence and release artifacts. No new TradingView Pine Editor evidence was collected, and no new oracle claims are made.

## Gates

Recorded during release preparation:

- `python -m pytest tests/unit/test_parser_* tests/integration/test_golden_ast_contract.py`
- `python -m pine2ast test-fixture tests/fixtures/valid/basic_indicator.pine`
- `bash scripts/release_gate.sh` when feasible in the local environment

Final command results are captured in the release manifest.
