# Changelog v3.7 / package 0.3.7

Release type: honest TradingView compile-oracle verification attempt over v3.6 coverage/oracle-expansion pending release.

## Changed

- Raised package metadata and runtime version from `0.3.6` to `0.3.7`.
- Attempted to verify the 30 v3.6 pending compile-oracle expansion fixtures using the existing TradingView browser profile at `/home/moltbot1/.config/tradingview-oracle-profile`.
- Recorded the real blocker in `TV_ORACLE_ATTEMPT_v3_7/`: TradingView opened the chart and Pine Editor, accepted fixture insertion, but pressing Ctrl+Enter/Add-to-chart displayed a `Sign in with email` modal.
- Kept all 30 expansion fixtures as `pending_external_oracle`; no new fixture-specific TradingView compile evidence is claimed.
- Preserved the prior v3.3 strategy-namespace TradingView evidence unchanged.
- Refreshed optimizer inspect contract snapshot metadata from `0.3.6` to `0.3.7`; payload shape and AST content are unchanged.

## Oracle status

- Verified external TradingView entries: 5 preserved strategy-namespace cases.
- Pending external TradingView entries: 30 expansion cases blocked by unauthenticated TradingView Pine Editor session.
- Invalid metadata entries: 0.
- Archive suffix remains `oracle_expansion_pending`, not `oracle_verified`.
