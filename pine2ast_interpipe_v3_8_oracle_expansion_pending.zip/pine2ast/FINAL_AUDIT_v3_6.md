# Final Audit v3.6 / package 0.3.6

## Scope

v3.6 starts from committed v3.5 parser modularization commit `71a51dc` and ships coverage hardening plus compile-oracle corpus expansion preparation. The release is deliberately named `coverage_oracle_expansion_pending` because the expanded oracle corpus has not been externally checked in TradingView.

## Implementation summary

- Package version is coherent at `0.3.6` in `pyproject.toml` and `pine2ast/__init__.py`.
- Coverage policy was tightened by removing prior omissions for CLI, SARIF, source map, semantic validators, and parser implementation modules.
- Added focused v3.6 tests in `tests/unit/test_v36_coverage_hardening.py` and expanded compile-oracle metadata tests.
- Added 30 pending compile-oracle fixtures across five new groups:
  - `declarations_core` — 6 fixtures.
  - `types_udt_enum_methods` — 6 fixtures.
  - `layout_wrapping` — 6 fixtures.
  - `collections` — 6 fixtures.
  - `request_inputs_strategy` — 6 fixtures.
- Local Pine2AST parse/semantic checks pass for the 30 new expansion fixtures. The two preserved strategy-namespace negative fixtures still intentionally emit the expected local policy diagnostics.
- Release-gate pending mode now requires either an RC package version or the explicit non-verified suffix `oracle_expansion_pending`.

## Compatibility assertions

- No AST schema changes were made.
- No new TradingView evidence was invented.
- Existing `TV_ORACLE_EVIDENCE_v3_3/` evidence and strategy-namespace metadata are preserved.
- Optimizer inspect JSON snapshots changed only in tool/producer version metadata (`0.3.5` → `0.3.6`).

## Oracle evidence

Compile-oracle metadata report from `reports/final/COMPILE_ORACLE_FINAL.json`:

- Metadata files: 6.
- Total fixtures: 35.
- Verified external TradingView entries: 5.
- Pending external TradingView entries: 30.
- Invalid metadata entries: 0.

The only externally verified corpus remains the preserved v3.3 strategy-namespace evidence. The 30 v3.6 expansion fixtures are pending external TradingView Pine Editor checks and must not be described as `oracle_verified`.

## Gates

Recorded during release preparation:

- `.venv/bin/python -m pytest tests/unit/test_compile_oracle_metadata.py tests/unit/test_v36_coverage_hardening.py -q` — pass, 7 tests.
- `.venv/bin/python -m pytest tests/unit tests/integration --cov=pine2ast --cov-report=term-missing --cov-report=xml` — pass, 266 tests, total coverage 90.24%.
- `bash scripts/release_gate.sh --allow-pending-oracle` — pass; final logs written under `reports/final/`.
- `.venv/bin/python -m compileall -q pine2ast tests tools` — pass.
- `.venv/bin/python tools/compile_oracle_report.py --path tests/fixtures/compile_oracle --json /tmp/compile_oracle_strict.json` — expected strict failure exit `1` because 30 external oracle entries are pending.

## Deferred / blockers

- Manual authenticated TradingView Pine Editor v6 compile checks are still required for the 30 expansion fixtures.
- After real evidence is captured, update each pending metadata entry and only then consider an `oracle_verified` archive suffix.
