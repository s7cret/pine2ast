# Changelog v3.5 / package 0.3.5

Release type: parser modularization hardening over v3.4 oracle evidence hardening.

## Changed

- Modularized the parser implementation while preserving the public `from pine2ast.parser import Parser` import path.
- Moved parser behavior into focused modules:
  - `parser/base.py` for parser state, orchestration, diagnostics, recovery, and lookahead helpers.
  - `parser/expressions.py` for expression parsing.
  - `parser/statements.py` for statements, blocks, loops, conditionals, and function bodies.
  - `parser/declarations.py` for imports, declarations, parameters, and type references.
- Left `parser/parser.py` as a thin facade class that composes the implementation mixins.
- Added parser architecture and migration notes in `docs/parser_architecture.md`.
- Added focused parser module-boundary tests for public imports, facade thinness, and the history-reference contract.
- Updated package metadata and runtime version from `0.3.4` to `0.3.5`.
- Refreshed optimizer inspect contract snapshot metadata from `0.3.4` to `0.3.5`; payload shape and AST content are unchanged.

## Compatibility

- No AST schema changes.
- No intentional parser behavior changes.
- Golden AST fixtures are unchanged.
- Pine block braces `{}` remain unsupported.
- Bracket postfix syntax remains `HistoryRefExpr`; no array-indexing AST was introduced.
- `input` remains outside declaration qualifier parsing.
- Semantic validation remains outside the parser.

## Oracle status

- v3.3/v3.4 TradingView Pine Editor evidence is preserved intact.
- v3.5 does not add or claim new TradingView oracle evidence.
- No fabricated TradingView evidence was added.
