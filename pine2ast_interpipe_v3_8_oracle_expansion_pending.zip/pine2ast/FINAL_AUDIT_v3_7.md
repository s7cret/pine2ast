# Final Audit v3.7 / package 0.3.7

## Scope

v3.7 starts from committed v3.6 commit `8dbd586` and attempts to close the 30 pending TradingView compile-oracle expansion fixtures. The release remains honestly pending because the existing TradingView profile was not authenticated for Pine Editor compile/add-to-chart.

## Implementation summary

- Package version is coherent at `0.3.7` in `pyproject.toml` and `pine2ast/__init__.py`.
- No parser, AST schema, or semantic runtime changes were made.
- The v3.6 compile-oracle expansion metadata was updated with the v3.7 blocker note, while preserving `pending_external_oracle` for all 30 expansion entries.
- A real browser-attempt record is stored in `TV_ORACLE_ATTEMPT_v3_7/`:
  - `signin_blocker_after_ctrl_enter.body.txt`
  - `signin_blocker_after_ctrl_enter.dom.json`
  - `signin_blocker_after_ctrl_enter.jpg`
  - `results.json`
- The blocker record is not fixture-specific compile evidence and must not be counted as verification.
- Existing `TV_ORACLE_EVIDENCE_v3_3/` evidence and strategy-namespace metadata are preserved.

## Oracle evidence

Compile-oracle metadata report from `reports/final/COMPILE_ORACLE_FINAL.json`:

- Metadata files: 6.
- Total fixtures: 35.
- Verified external TradingView entries: 5.
- Pending external TradingView entries: 30.
- Invalid metadata entries: 0.

The preserved v3.3 strategy-namespace corpus remains the only externally verified corpus. The 30 v3.6/v3.7 expansion fixtures are still pending external TradingView Pine Editor checks because the browser session displayed a sign-in modal during the verification attempt.

## Gates

Recorded during release preparation:

- `.venv/bin/python -m pytest tests/unit/test_compile_oracle_metadata.py -q` — pass.
- `bash scripts/release_gate.sh --allow-pending-oracle` — pass; final logs written under `reports/final/`.
- `.venv/bin/python -m compileall -q pine2ast tests tools` — pass.
- `.venv/bin/python tools/compile_oracle_report.py --path tests/fixtures/compile_oracle --json /tmp/compile_oracle_strict_v37.json` — expected strict failure exit `1` because 30 external oracle entries remain pending.

## Deferred / blockers

- A human must sign in to TradingView in `/home/moltbot1/.config/tradingview-oracle-profile` or provide another authenticated Pine Editor session before fixture-specific external compile evidence can be captured.
- Only after all pending entries have real Pine Editor evidence should metadata be changed to verified statuses and an `oracle_verified` archive be considered.
