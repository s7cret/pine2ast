# Changelog v3.6 / package 0.3.6

Release type: coverage hardening plus honest compile-oracle expansion preparation over v3.5 parser modularization.

## Changed

- Raised package metadata and runtime version from `0.3.5` to `0.3.6`.
- Removed obsolete coverage omissions after adding focused tests for CLI report paths, SARIF formatting, source-map construction, semantic validator exports, parser modules, type/qualifier edges, and semantic extractors.
- Documented the active v3.6 coverage policy and remaining justified omissions in `docs/coverage_policy.md`.
- Added 30 compile-oracle expansion fixtures across declarations, UDT/enums/methods, layout wrapping, collections, and request/input/strategy groups.
- Kept all new expansion fixtures marked `pending_external_oracle`; no new TradingView evidence is claimed.
- Added explicit pending production suffix handling for `oracle_expansion_pending` in `tools/compile_oracle_report.py` and `scripts/release_gate.sh`.
- Refreshed optimizer inspect contract snapshot metadata from `0.3.5` to `0.3.6`; payload shape and AST content are unchanged.

## Compatibility

- No AST schema changes.
- No intentional parser or semantic behavior regressions.
- The v3.3 strategy-namespace TradingView evidence is preserved intact.
- The v3.6 archive suffix is `coverage_oracle_expansion_pending`, not `oracle_verified`.

## Oracle status

- Verified external TradingView entries: 5 preserved strategy-namespace cases.
- Pending external TradingView entries: 30 new expansion cases.
- No fabricated TradingView evidence was added.
- Strict compile-oracle mode still exits non-zero until the 30 pending fixtures are manually checked in TradingView Pine Editor and metadata is updated with real evidence.
