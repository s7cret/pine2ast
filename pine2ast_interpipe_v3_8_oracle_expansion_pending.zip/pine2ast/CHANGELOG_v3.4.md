# Changelog v3.4 / package 0.3.4

Release type: release-consistency hardening over v3.3 oracle_verified.

## Changed

- Reconciled root release evidence around `pine2ast_interpipe_v3_4_oracle_verified.zip`.
- Archived stale v3.2/v3.3 root package artifacts under `reports/archive_pre_v3_4/` so root final logs no longer point at `v3_2_oracle_pending`.
- Kept the existing `TV_ORACLE_EVIDENCE_v3_3/` evidence intact. v3.4 does not claim new TradingView coverage beyond that verified P0 strategy namespace corpus.
- Updated package metadata and runtime version from `0.3.3` to `0.3.4`.
- Added current v3.4 limitations and explicit coverage policy documentation.
- Hardened release checklist and compile-oracle docs for strict production mode by default; pending oracle remains RC-only.
- Expanded contributor guidance for syntax nodes, semantic rules, builtin signatures, golden AST fixtures, oracle fixtures, and gates.

## Fixed

- `tools/run_tests_no_pytest.py` no longer crashes when a test module imports `pytest` in stdlib-only environments. It reports pass / skip / fail counts and treats pytest-only modules or unsupported fixtures as controlled skips.
- Root `RELEASE_MANIFEST_CHECK_FINAL.log` and `RELEASE_ZIP_FINAL.log` are regenerated for v3.4 during packaging.

## Compatibility

- No AST schema breaking changes.
- No parser behavior changes were intentionally introduced in v3.4.
- Parser modularization is deferred to v3.5 because v3.4 is a release-evidence hardening release; moving a 36 KB parser without a separate staged review would add unnecessary regression risk.

## Oracle status

- Oracle verified scope remains the v3.3 TradingView Pine Editor evidence in `TV_ORACLE_EVIDENCE_v3_3/` plus strict compile-oracle report generation.
- No fabricated TradingView evidence was added.
- Broader oracle expansion (UDT/enums/methods, collections, request/input/layout groups) is documented as a v3.5+ workstream unless real Pine Editor evidence is collected.
