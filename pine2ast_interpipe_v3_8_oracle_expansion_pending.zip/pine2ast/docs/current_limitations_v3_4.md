# Current limitations v3.4

Pine2AST v3.4 is a production-oriented parser/AST/semantic-analysis package, not a TradingView runtime or compiler. This document is the active limitations record for the `v3.4 oracle_verified hardening` release.

## What v3.4 verifies

- The local parser pipeline is exercised by the unit/integration suite, golden AST fixtures, smoke parsing, 300-file real-world quality gate, builtin coverage report, and compile-oracle metadata report.
- TradingView Pine Editor evidence is preserved from `TV_ORACLE_EVIDENCE_v3_3/` for the P0 strategy namespace fixtures only.
- Strict release mode requires compile-oracle metadata with no pending P0 fixture statuses.

## What v3.4 does not guarantee

- Pine2AST does not execute Pine code, simulate bars, produce trades, or evaluate indicator output.
- The AST is a normalized parse/semantic artifact, not a promise of byte-for-byte TradingView compiler internals.
- Oracle verification covers the named evidence corpus only; it is not a claim of complete TradingView compatibility.
- The builtin registry is an internal expected snapshot. It is versioned and tested, but it is not a complete official TradingView registry sync.
- Online import resolution is intentionally out of scope; imports are represented syntactically and semantically where local information is available.

## Known deferred surfaces

- Parser modularization: `pine2ast/parser/parser.py` remains concentrated in v3.4. Splitting it into declarations/statements/expressions/base is deferred to v3.5 because v3.4 intentionally avoids parser-behavior churn. The acceptance condition for that future split is unchanged golden AST output.
- Oracle expansion: v3.4 does not add new TradingView evidence. Future groups should cover declarations, UDT/enums/methods, layout wrapping, arrays/maps/matrices, request/input/strategy calls, and negative removed-parameter fixtures.
- Official builtin sync: registry coverage remains `internal_expected_snapshot_not_official_complete`. A future sync should diff against a dated official docs snapshot and add missing signatures with tests.
- `request.economic` and `runtime.error` must remain documented/deferred unless implemented with tests and oracle evidence. Do not silently claim support.

## Release discipline

- `oracle_verified` means there is concrete evidence for the stated corpus. Do not widen that wording without new evidence files and metadata.
- RC packages may use pending oracle mode; production packages must use strict mode.
- Root final logs should describe only the latest release. Historical logs/manifests/packages belong in `reports/archive_pre_v3_4/` or later archive directories.
