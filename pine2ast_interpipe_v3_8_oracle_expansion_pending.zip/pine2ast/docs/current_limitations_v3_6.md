# Current limitations v3.6

Pine2AST v3.6 / package 0.3.6 is a production-oriented parser/AST/semantic-analysis package, not a TradingView runtime or compiler.

## What v3.6 verifies

- Parser modularization from v3.5 remains behavior-preserving; no AST schema version change is introduced.
- `[]` remains represented as `HistoryRefExpr`; Pine `{}` blocks remain unsupported because they are not Pine syntax.
- `input` is still not treated as a declaration qualifier.
- Coverage policy is tightened: CLI, SARIF, source-map, semantic validators, and modular parser files are back in threshold math.
- The existing v3.3 P0 TradingView evidence under `TV_ORACLE_EVIDENCE_v3_3/` remains the only externally verified oracle evidence.

## What v3.6 does not guarantee

- The 30 new oracle expansion fixtures are metadata/corpus preparation only. They are marked `pending_external_oracle` until a real TradingView Pine Editor check captures evidence.
- The release archive is therefore named with `oracle_expansion_pending`, not `oracle_verified`.
- Pine runtime execution, broker behaviour, chart rendering, alert delivery, and TradingView UI behaviour are outside Pine2AST scope.
- Some semantic rules are conservative static checks and may intentionally differ from TradingView runtime evaluation until external evidence is collected.

## Next oracle blockers

To convert the expanded corpus to verified status, each pending fixture needs a manual TradingView Pine Editor v6 compile attempt with saved body/DOM/screenshot evidence and a status update from `pending_external_oracle` to `ok`, `pass`, `invalid_expected`, or `fail_expected` as appropriate.
