# Current limitations v3.7

Pine2AST v3.7 / package 0.3.7 is a production-oriented parser/AST/semantic-analysis package, not a TradingView runtime or compiler.

## What v3.7 verifies

- Local parser, AST, semantic, quality-gate, and compile-oracle metadata integrity through the release gate.
- The preserved v3.3 TradingView Pine Editor evidence for the strategy-namespace oracle corpus.
- A real v3.7 TradingView browser attempt for the expanded oracle corpus, recorded as a blocker rather than verification.

## What v3.7 does not guarantee

- The 30 v3.6 expansion fixtures are not externally verified yet.
- `TV_ORACLE_ATTEMPT_v3_7/` proves only that the attempt reached a TradingView sign-in blocker after fixture insertion; it is not compile evidence.
- Strict compile-oracle mode still fails until the 30 pending entries are checked in an authenticated TradingView Pine Editor session.
