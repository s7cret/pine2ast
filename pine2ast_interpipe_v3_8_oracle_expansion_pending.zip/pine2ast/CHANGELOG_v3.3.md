# v3.3 oracle_verified / 0.3.3

- Replaced oracle-pending status with authenticated TradingView Pine Editor v6 compile evidence for all P0 strategy namespace fixtures.
- Fixed the library oracle fixture title to a valid Pine library identifier while preserving the `strategy.long` coverage intent.
- Added captured oracle evidence under `TV_ORACLE_EVIDENCE_v3_3/`.
- Strict compile-oracle now reports `pending_count=0` and `ok=true`.
