# Coverage policy

Pine2AST uses coverage as a release signal, not as a cosmetic number. The v3.4 gate keeps core package coverage at or above the configured threshold while documenting every active omit.

## Required gate

```bash
python -m pytest tests/unit tests/integration --cov=pine2ast --cov-report=term-missing --cov-report=xml
```

The XML report is written to `coverage.xml`; the terminal report is captured in `reports/final/TEST_RUN_FINAL.log` by `scripts/release_gate.sh`.

## Omit policy

A file may remain omitted only when one of these is true:

1. It is tiny process glue better covered by subprocess smoke tests than line coverage.
2. It is timing/environment-sensitive and line coverage would incentivize brittle tests.
3. It is a compatibility shim or parser split placeholder whose behavior is exercised through the public parser facade.
4. It is a future integration surface with explicit documentation and separate smoke coverage.

## Current v3.4 omissions and reasons

- `pine2ast/__main__.py`: module entry-point shim; covered through CLI invocation paths.
- `pine2ast/cli.py`: command dispatch and filesystem/stdout glue. It has smoke coverage, but full branch coverage would require many subprocess/error environment permutations. Future work should add targeted CLI subprocess tests before removing this omit.
- `pine2ast/benchmark.py`: timing-oriented helper; correctness is covered by benchmark smoke commands, not threshold math.
- `pine2ast/layout/indentation.py`, `pine2ast/layout/line_wrapping.py`: implementation helpers covered through `LayoutProcessor` and parser integration fixtures.
- `pine2ast/parser/declarations.py`, `pine2ast/parser/expressions.py`, `pine2ast/parser/statements.py`: v3.4 still uses these as compatibility stubs/re-export surfaces pending v3.5 modularization.
- `pine2ast/semantic/validators.py`: validator integration surface; keep omitted until either merged into analyzer or covered by direct semantic rule tests.
- `pine2ast/source/source_map.py`: source-map utility; future work should add focused span/offset mapping tests and remove the omit.
- `pine2ast/testing/fixtures.py`: test helper module, not runtime parser logic.
- `pine2ast/diagnostics/sarif.py`: SARIF formatter; future work should add JSON-shape smoke tests and remove the omit.
- `pine2ast/lexer/trivia.py`: trivia helper covered indirectly through lexer tests.

## Cleanup backlog

The preferred v3.5 cleanup is to remove omissions for CLI, SARIF, source-map and semantic validators by adding focused tests. Parser split stubs should disappear from the omit list once parser modularization is complete. Omitted files must not be used to hide known failing runtime code.
