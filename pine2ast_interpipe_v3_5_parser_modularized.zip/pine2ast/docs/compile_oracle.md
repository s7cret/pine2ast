# Compile oracle metadata

Pine2AST does not call TradingView or any network service from the CLI. Compile-oracle fixtures are a manually checked evidence layer for Pine cases where TradingView behaviour matters for production sign-off.

## Evidence layout for oracle_verified releases

- `tests/fixtures/compile_oracle/` contains the checked `.pine` fixtures and category metadata.
- `TV_ORACLE_EVIDENCE_*` contains real external evidence snapshots when TradingView Pine Editor has been used: screenshot, DOM/body captures, and a `results.json` summary.
- `reports/final/COMPILE_ORACLE_FINAL.json` is generated from fixture metadata and records pending/pass/fail counts.
- The final audit states exactly which evidence directory supports the release claim.

For v3.4, the preserved external evidence is `TV_ORACLE_EVIDENCE_v3_3/`. v3.4 does not widen the verified corpus unless new real evidence is added.

## Metadata format

Each oracle category stores a `metadata.json` next to its `.pine` fixtures:

```json
{
  "schema_version": 2,
  "pine_version": 6,
  "checked_at": "2026-04-27",
  "oracle": "TradingView Pine Editor evidence captured in TV_ORACLE_EVIDENCE_v3_3 for this fixture group",
  "policy": [
    {
      "fixture": "strategy_closedtrades_allowed.pine",
      "context": "strategy",
      "usage": "strategy.closedtrades.entry_price/comment",
      "expected": "allowed",
      "pine2ast_status": "pass",
      "tradingview_status": "pass"
    }
  ]
}
```

`tradingview_status` values:

- `pass` / `ok` — manually compiled successfully in TradingView Pine Editor.
- `fail_expected` / `invalid_expected` — manually failed in TradingView with the expected policy/semantic error.
- `pending_external_oracle` — not manually checked yet. This is allowed for RC packaging only with `--allow-pending`, but blocks production sign-off.

Do not invent TradingView statuses. If no Pine Editor access is available, leave `pending_external_oracle` and let the strict report fail explicitly.

## Report command

```bash
python tools/compile_oracle_report.py \
  --path tests/fixtures/compile_oracle \
  --json reports/final/COMPILE_ORACLE_FINAL.json
```

Exit codes:

- `0` — all metadata is valid and no P0 fixture is pending.
- `1` — metadata is structurally valid but at least one fixture is still `pending_external_oracle`.
- `2` — invalid metadata or missing fixture file.

For local RC snapshots before manual TradingView sign-off:

```bash
python tools/compile_oracle_report.py \
  --path tests/fixtures/compile_oracle \
  --json reports/final/COMPILE_ORACLE_FINAL.json \
  --allow-pending
```

## Expansion policy

New oracle groups should be added only when metadata and evidence are available. Useful future groups are declarations, UDT/enums/methods, layout wrapping, collections, and request/input/strategy cases. A fixture with no external evidence is valuable as local regression coverage, but it must not be used to broaden `oracle_verified` claims.
