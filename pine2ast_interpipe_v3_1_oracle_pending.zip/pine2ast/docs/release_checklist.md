# Release packaging checklist

## Quality/performance commands

For v3.1 RC packaging with an honest pending TradingView oracle:

```bash
bash scripts/release_gate.sh --allow-pending-oracle
python tools/build_release_zip.py . pine2ast_interpipe_v3_1_oracle_pending.zip --manifest RELEASE_MANIFEST_v3_1_oracle_pending.json
python tools/check_release_manifest.py RELEASE_MANIFEST_v3_1_oracle_pending.json
```

Strict release mode omits `--allow-pending-oracle` and must be used only after external Pine Editor oracle evidence is available. See `docs/current_limitations_v3_1.md`.

Legacy/manual commands:

```bash
PYTHONPATH=. python -S tools/run_tests_no_pytest.py
PYTHONPATH=. python -m pine2ast perf-baseline tests/fixtures/inspect_contract --repeat 20 --json PERFORMANCE_BASELINE_v2_15_1.json
python tools/build_release_zip.py . ../pine2ast_release.zip --manifest RELEASE_MANIFEST.json
```

`perf-baseline` wraps the existing parser benchmark in a release-facing JSON report:

- `schema_version: 1`
- `report: pine2ast.performance_baseline`
- `ok: true` when files parse cleanly and baseline comparison has no >25% per-file regression warnings
- raw benchmark payload under `bench`

## Archive policy

`tools/build_release_zip.py` builds deterministic ZIP archives by sorting entries, pinning ZIP timestamps to `1980-01-01 00:00:00`, and normalizing file permissions.

The archive excludes:

- VCS/cache/build folders: `.git`, `__pycache__`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `.tox`, `build`, `dist`
- virtualenv/temp folders: `venv`, `.venv`, `env`, `tmp`, `temp`
- compiled/native artifacts: `.pyc`, `.pyo`, `.pyd`, `.so`
- likely secrets by filename fragment: `secret`, `secrets`, `.env`, `id_rsa`, `id_ed25519`

The optional manifest records SHA-256, file count, exclusion policy and three checks: no pycache, no temp/venv, no secret-like filenames.
