# Changelog v2.13.0

Release date: 2026-04-27
Base: `pine2ast_interpipe_v2_12_0`
Package version: `0.2.13`

## Added

- Registry metadata v2 pack for additional `request.*` calls:
  - `request.financial`
  - `request.dividends`
  - `request.earnings`
  - `request.splits`
  - `request.currency_rate`
  - `request.seed`
- Typed constant pack in `builtins_v6.json`:
  - `display.*`
  - `line.style_*`
  - `label.style_*`
  - additional `position.*`
  - `barmerge.gaps_*`
  - `barmerge.lookahead_*`
  - `dividends.*`, `earnings.*`, `splits.*`
- Strategy risk metadata pack:
  - `strategy.risk.allow_entry_in`
  - `strategy.risk.max_drawdown`
  - `strategy.risk.max_intraday_loss`
  - `strategy.risk.max_cons_loss_days`
  - `strategy.risk.max_intraday_filled_orders`
- Committed baseline reports under `tests/fixtures/baselines/v2_13/`:
  - `diagnostics_01_ma_indicator.json`
  - `builtin_coverage.json`
  - `semantic_01_ma_indicator.json`
- Focused regression suite: `tests/unit/test_bigblock_v2_13.py`.

## Changed

- Package version bumped to `0.2.13`.
- `input.*(..., display=...)` is now typed as `display`, not loose `any`.
- Enum-like typed constants are assignable to matching enum-like builtin parameters.
- `line.new(chart.point, chart.point, ...)` overload is accepted without weakening numeric overload validation.
- Builtin coverage expectations now track typed style/display/barmerge/request constants.

## Verified

```text
python -S tools/run_tests_no_pytest.py
→ 175 passed

python -S -m pine2ast.cli validate-corpus tests/fixtures/real_world --json CORPUS_RUN_v2_13_0.json
→ file_count=300, ok_count=300, error_count=0

python -S -m pine2ast.cli quality-gate tests/fixtures/real_world --json QUALITY_GATE_v2_13_0.json
→ ok=true, file_count=300, ok_count=300, error_count=0, warning_count=1

python -S -m pine2ast.cli schema-check tests/fixtures/real_world/01_ma_indicator.pine --json SCHEMA_CHECK_v2_13_0.json
→ parse_ok=true, schema.ok=true

python -S -m pine2ast.cli builtin-coverage --json BUILTIN_COVERAGE_v2_13_0.json
→ function_count=278, variable_count=103, missing_expected=0

python -S -m compileall -q pine2ast tests/unit/test_bigblock_v2_13.py
→ ok
```

## Notes

- AST schema is unchanged.
- External TradingView compile-oracle statuses remain pending because Pine Editor access is outside this offline build environment.
