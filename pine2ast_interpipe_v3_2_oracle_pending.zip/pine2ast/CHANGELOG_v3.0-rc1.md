# v3.0-rc1 / 0.3.0rc1

Final production-candidate packaging/sign-off build.

## Included

- Package version set to PEP 440 `0.3.0rc1`.
- Release evidence normalized to final artifact names.
- Documentation aligned for grammar, AST schema, semantic model, diagnostics, builtin registry, compile oracle, optimizer contract, and release checklist.
- Final audit/report set generated at repository root.

## Gate policy

Required local gates must pass before release packaging:

- ruff
- black --check
- mypy over `pine2ast`
- unit + integration pytest with coverage
- compile-oracle report with `--allow-pending`
- real-world quality gate
- builtin coverage
- release manifest validation

## Known blocker

TradingView Pine Editor oracle checks are still pending because this environment has no authenticated TradingView Pine Editor access. This release therefore remains `oracle_pending` and does not claim external compile confirmation.
