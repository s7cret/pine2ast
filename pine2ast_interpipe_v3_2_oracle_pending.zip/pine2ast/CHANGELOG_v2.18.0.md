# Pine2AST v2.18.0 — Layout/Parser Real Pine Hardening

## Changed

- Bumped package version to `0.2.18`.
- Added v2.18 layout/parser fixtures for nested calls, multiline declaration calls, chained member calls, comments-only wrapped calls, multiline strings near wrapping, multiline switch bodies, if-expression assignment, and wrapped tuple targets.
- Added integration token snapshots for `NEWLINE`/`INDENT`/`DEDENT`-sensitive delimiter cases.

## Improved

- Improved layout recovery when an unclosed delimiter is followed by a new statement at an active block indentation; the parser now reports the missing closer instead of hiding the rest of the file in one wrapped logical line.
- Improved parser recovery for missing `)`/`]` so statement-boundary tokens are preserved for outer recovery.
- Improved missing-block recovery after `if`/`for`/`while`/`switch` forms so a bad indentation error does not consume the following top-level statement.

## Constraints Honored

- No AST schema change.
- No Pine block implementation via `{}`.
- `input` remains an ordinary identifier/member namespace, not a declaration keyword or qualifier.
- `[]` remains `HistoryRefExpr`, not array indexing.
- Semantic validation remains in the semantic layer.

## Evidence

- TradingView Pine Editor compile-oracle remains `pending_external_oracle`; no compile-oracle result is fabricated.
- Release evidence is generated as `RUFF_v2_18_0.log`, `BLACK_v2_18_0.log`, `MYPY_v2_18_0.log`, `TEST_RUN_v2_18_0.log`, `QUALITY_GATE_LOCAL_v2_18_0.json`, `CORPUS_RUN_v2_18_0.json`, `LAYOUT_SNAPSHOT_v2_18_0.json`, `BUILTIN_COVERAGE_v2_18_0.json`, `coverage.xml`, and `COVERAGE_v2_18_0.md`.
