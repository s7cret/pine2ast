# pine2ast v2.12.0 — bigblock hardening

Дата: 2026-04-27
База: `pine2ast_interpipe_v2_11_0`

## Сделано

### P0 / regression

- Поднят package version до `0.2.12`.
- Полный stdlib runner в текущей рабочей копии прошёл: `167 passed`.
- Добавлен focused-набор `tests/unit/test_bigblock_v2_12.py` на 11 проверок.
- Builtin coverage smoke: `function_count=276`, `missing_expected=0`.
- Schema smoke для `01_ma_indicator.pine`: `parse_ok=true`, `schema.ok=true`.

### P1 / narrowing semantics

- Добавлен diagnostic code `P2A1903 UNSTABLE_NA_NARROWING`.
- Добавлена проверка unstable `na()` guards:
  - `na(x)` и `na(obj.field)` дают stable flow-fact;
  - `na(close + open)`, `na(1)` и аналогичные выражения получают `INFO P2A1903` и не создают fake narrowing.
- Зафиксированы regression tests:
  - `if not na(x) and not na(y)`;
  - nested `and`;
  - negative `or` case без unsound narrowing;
  - branch-local `else if` facts без leakage между ветками.

### P1 / builtin registry metadata

Расширены priority registry entries:

- Drawing constructors:
  - `line.new`;
  - `label.new`;
  - `box.new`;
  - `table.new`;
  - `polyline.new`.
- Drawing setters:
  - `line.set_xy1`, `line.set_xy2`;
  - `label.set_x`, `label.set_y`, `label.set_text`;
  - `box.set_left`, `box.set_right`, `box.set_top`, `box.set_bottom`;
  - `table.set_position`.
- Strategy order calls:
  - `strategy.entry`;
  - `strategy.exit`;
  - `strategy.order`.
- Request calls:
  - `request.security`;
  - `request.security_lower_tf`.
- Inputs:
  - `input.int`;
  - `input.float`;
  - `input.bool`;
  - `input.string`;
  - `input.timeframe`.

`strategy.*(..., when=...)` по-прежнему диагностируется как removed in Pine v6.

### P1 / compile-oracle metadata

- `tests/fixtures/compile_oracle/strategy_namespace/metadata.json` поднят до schema version 2.
- Добавлены `pine2ast_status=pass` для внутренних semantic policy fixtures.
- `tradingview_status` честно оставлен как `pending_external_oracle`, потому что фактический TradingView compile oracle в этом окружении недоступен.

## Проверки

```text
python -S tools/run_tests_no_pytest.py
→ 167 passed

focused tests/unit/test_bigblock_v2_12.py
→ 11 passed

python -S -m pine2ast.cli builtin-coverage --json BUILTIN_COVERAGE_v2_12_0.json
→ function_count=276
→ missing_expected=0

schema smoke 01_ma_indicator.pine
→ parse_ok=true
→ schema.ok=true
```

## Ограничения этого прогона

Полный `validate-corpus` / `quality-gate` по 300 fixtures снова не удалось завершить честно из-за внешних helper-процессов, которые сканируют старые `/mnt/data/work_v28` и `/mnt/data/work_v29` пути и забивают CPU. Это не связано с кодом `pine2ast`; рабочий код и unit regression прогон выполнялись из `/tmp`.
