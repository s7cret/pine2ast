# Pine2AST v2.17.0 — Semantic, Typing and Diagnostics Stabilization

## Changed

- Bumped package version to `0.2.17`.
- Documented the stable diagnostics contract in `docs/diagnostics.md`.
- Added a v2.17 semantic rule matrix covering declaration/reassignment, redeclaration, const reassignment, Pine v6 bool/`na`, history references, break/continue, nested functions, method receivers, import alias conflicts, unknown builtin members, and unknown namespaces.

## Improved

- Preserved generic collection constructor types for `array.new<T>()`, `matrix.new<T>()`, and `map.new<K,V>()` without changing the AST schema.
- Strengthened typed Python structures for builtin coverage reports, compile-oracle payloads, and golden invalid-diagnostic contracts.

## Evidence

- TradingView Pine Editor compile-oracle remains `pending_external_oracle`; no compile-oracle result is fabricated.
- Release evidence is generated as `MYPY_v2_17_0.log`, `TEST_RUN_v2_17_0.log`, `QUALITY_GATE_LOCAL_v2_17_0.json`, `DIAGNOSTICS_INVALID_ALL_v2_17_0.json`, `BUILTIN_COVERAGE_v2_17_0.json`, `coverage.xml`, and `COVERAGE_v2_17_0.md`.
