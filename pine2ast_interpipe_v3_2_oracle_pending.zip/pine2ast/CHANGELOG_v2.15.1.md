# Pine2AST v2.15.1 — Compile-oracle metadata tooling

Дата: 2026-04-27

## Что закрыто

- Добавлен offline report/validator для TradingView compile-oracle metadata:
  - `tools/compile_oracle_report.py`;
  - `pine2ast.testing.compile_oracle.build_compile_oracle_report()`;
  - JSON serialization через `report_to_dict()`.
- Добавлена документация `docs/compile_oracle.md` с допустимыми статусами и exit codes.
- Добавлен unit test `tests/unit/test_compile_oracle_metadata.py`.
- Сгенерирован текущий evidence-report `COMPILE_ORACLE_v2_15_0.json`.

## Проверки

- `compileall` по `pine2ast tests tools benchmarks` — pass.
- `tools/run_tests_no_pytest.py` — 176 passed.
- `tools/compile_oracle_report.py --path tests/fixtures/compile_oracle --json COMPILE_ORACLE_v2_15_0.json` возвращает exit code `1`, потому что 5 P0 fixtures всё ещё имеют `pending_external_oracle`.

## Ограничения

- TradingView статусы не подделывались. Ручная проверка в Pine Editor всё ещё нужна для production sign-off.
