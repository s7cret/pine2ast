# Pine2AST v2.11.0

Дата: 2026-04-27
База: `pine2ast_interpipe_v2_10_0`

## Что сделано

- Поднята версия пакета до `0.2.11`.
- Расширен flow-sensitive `na()` narrowing:
  - `if not na(x) and x > 0` теперь даёт non-`na` факт для тела `if`;
  - `if not na(obj.field)` сохраняет member-path факт `obj.field`;
  - `if na(x) ... else ...` сохраняет non-`na` факт для `else`-ветки;
  - narrowing остаётся scope-local и не переносится в sibling/global scope.
- Добавлен JSON-safe слой metadata: `SemanticModel.non_na_paths`.
- `semantic-report` обновлён до schema version 2 и теперь отдаёт:
  - `scope.non_na_symbols`;
  - `scope.non_na_paths`;
  - `narrowing_count`.
- Добавлены focused tests: `tests/unit/test_bigblock_v2_11.py`.
- Обновлена документация grammar note по flow-sensitive narrowing.

## Проверки в текущем окружении

Успешно:

```text
focused tests/unit/test_bigblock_v2_11.py
→ 4 passed

python -S -m py_compile pine2ast/semantic/analyzer.py pine2ast/semantic/reports.py tests/unit/test_bigblock_v2_11.py
→ ok

builtin coverage direct smoke
→ function_count=275
→ missing_expected=0
```

Ограничение окружения:

Полный `tools/run_tests_no_pytest.py`, CLI `validate-corpus` и часть schema/corpus smoke снова были сорваны внешними helper-процессами, непрерывно проверяющими старые `/mnt/data/work_v28` и `/mnt/data/work_v29` пути. Из-за этого полный clean-environment regression остаётся P0 для следующего запуска в чистом окружении.

## Совместимость

AST schema не менялась. Изменён только semantic-report schema (`1` → `2`) за счёт optional report metadata.
