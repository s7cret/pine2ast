# v3.2-rc1 / 0.3.2rc1

Oracle-pending packaging/evidence hardening RC over v3.1.

- Added `scripts/smoke_import_parse.sh` and wired it into `scripts/release_gate.sh`.
- Hardened compile-oracle status handling: legacy `pass`/`fail_expected` and newer `ok`/`invalid_expected` are accepted only as explicit metadata values; `pending_external_oracle` still fails strict mode.
- Restricted compile-oracle `--allow-pending` to RC package versions.
- Refreshed release evidence naming for `v3.2` and archived stale root v3.0/v3.1 final artifacts under `reports/archive_pre_v3_2/`.
- No AST schema change; TradingView compile oracle remains pending until external Pine Editor evidence is captured.
