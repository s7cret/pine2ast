# v2.20.0 - AST2Python / Optimizer Integration Contract Freeze

Package version: `0.2.20`

## Added

- Hardened `pine2ast inspect` v1 payload with explicit `producer`, enriched `source`, `script`, and `unsupported_features` fields while preserving `pine2ast.inspect.optimizer.v1` compatibility.
- Added v2.20 optimizer-contract Pine fixtures and golden inspect snapshots for:
  - basic strategy inputs;
  - TP/SL/trailing-style strategy exits;
  - `request.security` tuple payloads;
  - multiple input types and options;
  - array/map usage;
  - plot/alert/drawing extraction;
  - import alias external calls.
- Added `tests/integration/test_optimizer_contract_v2_20.py` for snapshot and required-field coverage.
- Added `docs/optimizer_contract.md` and `docs/ast2python_contract.md` with schema/contract bump policy and unsupported-feature handling.

## Constraints kept

- AST schema unchanged; no schema-version bump required.
- `[]` remains history-reference/tuple syntax per existing AST rules, not array indexing.
- `input` remains a builtin namespace, not a declaration keyword/qualifier.
- Pine `{}` blocks remain unsupported.
- Semantic validation remains in the semantic layer.
- TradingView compile-oracle remains `pending_external_oracle`; no oracle result was faked.

## Verification

Release gates are captured in v2.20 artifacts:

- `RUFF_v2_20_0.log`
- `BLACK_v2_20_0.log`
- `MYPY_v2_20_0.log`
- `TEST_RUN_v2_20_0.log`
- `COVERAGE_v2_20_0.md`
- `QUALITY_GATE_LOCAL_v2_20_0.json`
- `BUILTIN_COVERAGE_v2_20_0.json`
- `OPTIMIZER_CONTRACT_v2_20_0.json`
- `RELEASE_MANIFEST_v2_20_0_oracle_pending.json`
