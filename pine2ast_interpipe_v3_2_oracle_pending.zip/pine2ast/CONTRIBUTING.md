# Contributing

When adding syntax:

1. Add lexer/layout/parser tests.
2. Add a golden AST fixture when AST schema changes.
3. Add semantic diagnostics and tests for language rules.
4. Do not add C-like pseudo-syntax for Pine blocks.
5. Keep `builtins_v6.json` schema stable and versioned.
