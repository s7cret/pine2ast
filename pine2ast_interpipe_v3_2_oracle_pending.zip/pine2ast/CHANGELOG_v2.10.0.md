# pine2ast v2.10.0

Date: 2026-04-27
Base: v2.9.0

## Added

- Expanded builtin registry coverage so `builtin_registry_coverage_report()` has no `missing_expected` entries for the v2.9 expected namespace backlog.
- Added registered signatures for:
  - `str.tonumber`;
  - missing `line.*` getters;
  - missing `label.*` getters/setters;
  - missing `box.*` edge setters;
  - `table.set_position`;
  - `polyline.new/delete`;
  - `strategy.closedtrades.entry_comment/exit_comment`;
  - `strategy.opentrades.entry_comment`.
- Added semantic metadata for scope-local non-`na` narrowing from `if not na(x)` guards.
- Added compile-oracle fixture set for strategy namespace policy under `tests/fixtures/compile_oracle/strategy_namespace/`.
- Added `tests/unit/test_bigblock_v2_10.py`.

## Changed

- `pine2ast.__main__` now lazily imports the CLI module. Importing `pine2ast.__main__` is cheap and no longer loads the full CLI dependency graph.
- Builtin registry loader now reads `builtins_v6.json` via `Path(__file__).with_name(...)` instead of `importlib.resources`, avoiding slow resource discovery in constrained/prefetch-heavy environments.
- `docs/grammar.md` documents strategy namespace constants vs runtime strategy state policy.

## Validation

- Focused v2.10 tests: passed (`TEST_RUN_v2_10_0_FOCUSED.log`).
- Builtin coverage: `function_count=275`, `missing_expected=0` (`BUILTIN_COVERAGE_v2_10_0.json`).
- Schema smoke on `01_ma_indicator.pine`: `parse_ok=true`, `schema.ok=true` (`SCHEMA_CHECK_v2_10_0.json`).
- Full stdlib runner and full corpus run were attempted but interrupted by the same external `/mnt/data/work_v28/work_v29` prefetch/stat helper CPU issue observed in v2.9. Partial log is kept as `TEST_RUN_v2_10_0_PARTIAL_ENV_TIMEOUT.log`.
