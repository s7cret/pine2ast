# Pine2AST v2.16.0 — Evidence/Sign-off Hardening

## Changed

- Bumped package version to `0.2.16` and aligned v2.16.0 release artifacts.
- Made `mypy` a green gate: `python -m mypy pine2ast` passes with zero issues.
- Raised coverage gate to `fail_under = 90` and added targeted coverage for semantic type/qualifier and golden helper contracts.
- Added reproducible release helpers:
  - `tools/build_release.py --version ...`
  - `tools/check_release_manifest.py ...`
- Updated CI so ruff, black, pytest+coverage, mypy, compile-oracle report, and quality wrapper are explicit gates/artifacts.
- Refreshed quality evidence logs/reports for v2.16.0:
  - `RUFF_v2_16_0.log`
  - `BLACK_v2_16_0.log`
  - `MYPY_v2_16_0.log`
  - `TEST_RUN_v2_16_0.log`
  - `COVERAGE_v2_16_0.md`
  - `QUALITY_GATE_LOCAL_v2_16_0.json`
  - `BUILTIN_COVERAGE_v2_16_0.json`
  - `COMPILE_ORACLE_v2_16_0.json`

## Evidence

- `python -m ruff check .` — pass
- `python -m black --check .` — pass
- `python -m mypy pine2ast` — pass, `0` issues
- `python -m pytest tests/unit tests/integration --cov=pine2ast --cov-report=term-missing --cov-report=xml` — `213 passed`, coverage `90.18%`
- `python -m pine2ast quality-gate tests/fixtures/real_world --json QUALITY_GATE_LOCAL_v2_16_0.json` — `300/300 ok`
- `python -m pine2ast builtin-coverage --json BUILTIN_COVERAGE_v2_16_0.json` — internal expected coverage green

## Honest external blocker

TradingView compile-oracle P0 metadata is still `pending_external_oracle` for 5 fixtures because no TradingView Pine Editor manual check was available in this environment. The status is not faked. The strict command still returns non-zero until those external checks are performed:

```bash
python tools/compile_oracle_report.py --path tests/fixtures/compile_oracle --json COMPILE_ORACLE_v2_16_0.json
```

A pending-tolerant report is included as `COMPILE_ORACLE_v2_16_0_PENDING.json` for reproducible local evidence without claiming full external sign-off.
