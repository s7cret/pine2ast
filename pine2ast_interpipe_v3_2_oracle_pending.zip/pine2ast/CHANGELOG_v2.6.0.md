# Changelog v2.6.0

## База

Релиз собран поверх доступной рабочей точки `pine2ast_interpipe_v2_4_0` с сохранением v2.x API/AST schema.

## Реализовано

- Восстановлен полный real-world corpus до 300 `.pine` fixtures из `v2.3.0` (`copied=55`).
- Добавлен inactive compatibility harness `tests/unit_legacy_v1_18/` (`legacy test files=17`, checks=105).
- Добавлен `docs/legacy/v1_18/PORTING_MATRIX.md`: `ported=66`, `obsolete=29`, `blocked=10`.
- Добавлены активные hardening tests `tests/unit/test_bigblock_v2_6.py`.
- Добавлен backward-compatible `ArrayLiteralExpr = TupleExpr` alias без изменения JSON kind/schema.
- Усилен semantic analyzer:
  - duplicate enum member diagnostics;
  - unknown enum member diagnostics;
  - duplicate UDT field diagnostics;
  - tuple destructuring rejects non-tuple initializer;
  - tuple destructuring rejects arity mismatch;
  - `_` in `for-in` tuple target no longer leaks into symbol table;
  - unary `not` now requires bool operand;
  - unknown scalar/UDT/collection method diagnostics;
  - UDT field call (`p.field()`) is diagnosed as non-callable;
  - `map.get()` validates key type in function form and method form;
  - `array.from()` preserves mixed non-numeric arrays as incompatible with typed arrays.
- Registry fix: `ta.macd` now returns `tuple<float,float,float>`.

## Проверки

See `TEST_RUN_v2_6_0.log`.

## Не делалось

- Legacy tests from `tests/unit_legacy_v1_18/` remain non-blocking by design.
- Remaining `blocked` items are listed in `pine2ast_tz_detailed_v1_4_remaining.md`.
