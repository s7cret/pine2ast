# Pine2AST Interpipe v2.4.0

Дата релиза: 2026-04-26

## Что сделано

- Базой релиза оставлена ветка `pine2ast_interpipe_v2_3_0_bigblock`.
- Сохранены сильные стороны v2.3: CLI `parse/tokens/validate/bench/inspect`, corpus validation, quality gate, SARIF/diagnostic reports, schema validation, 300 real-world fixtures и текущий зелёный regression-набор.
- Из `v1.18.0 hardening` добавлены legacy-артефакты для сверки:
  - `docs/legacy/v1_18/CHANGELOG_v1.*.md`;
  - `docs/legacy/v1_18/VERIFICATION_SUMMARY.md`;
  - `tests/fixtures/legacy_v1_18_valid/*.pine`.
- Версия пакета поднята до `0.2.4`.
- Добавлен документ `docs/merge_v2_4.md` с результатом сравнения двух веток.
- Добавлено ТЗ `pine2ast_tz_detailed_v1_2_remaining.md` с остатком hardening-доработок до полного схождения веток.

## Почему не был сделан слепой overlay ядра v1.18

Прямая замена ядра v2.3 на v1.18 возвращает часть старых semantic-hardening проверок, но ломает v2.x сценарии по CLI/quality/corpus/schema/reporting и часть новых проверок типов/извлечения optimizer payload. Поэтому v2.4 — безопасный релиз поверх v2.3, а несовместимые semantic-hardening пункты выделены в ТЗ 1.2.

## Проверка

Использован stdlib-only runner:

```bash
python -S tools/run_tests_no_pytest.py
```

Ожидаемый baseline v2.3/v2.4: `120 passed`.

Фактический локальный прогон в текущем окружении: `120 passed` через `tools/run_tests_no_pytest.py`. Из-за зависания sitecustomize в системном Python использовался `python -S`.
