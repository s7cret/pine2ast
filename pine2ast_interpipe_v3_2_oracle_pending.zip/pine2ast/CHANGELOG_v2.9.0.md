# Pine2AST v2.9.0

Дата: 2026-04-27
База: `pine2ast_interpipe_v2_8_0`

## Что добавлено

1. **Diagnostic dedupe policy**
   - добавлена общая дедупликация diagnostics в `parse_code()`;
   - закрыт кейс, где malformed `for [a, b, c] in ...` мог получать два одинаковых `P2A1902` из parser recovery и semantic fallback.

2. **Strict builtin namespace mode**
   - добавлен `ParseOptions.strict_builtin_namespaces: bool = False`;
   - по умолчанию unknown member известного builtin namespace остаётся `INFO P2A1506`;
   - в strict mode тот же `P2A1506` повышается до `ERROR`;
   - CLI-команды parse/validate/dump-symbols/inspect/schema-check/diagnostics-report/sarif/semantic-report/quality-gate/golden получили флаг `--strict-builtin-namespaces`.

3. **Builtin registry coverage report**
   - добавлен `builtin_registry_coverage_report()`;
   - добавлена CLI-команда `pine2ast builtin-coverage --json out.json`;
   - отчёт показывает покрытие namespaces и missing expected members для ключевых групп: `ta`, `math`, `str`, `color`, drawing namespaces, `strategy.closedtrades`, `strategy.opentrades`.

4. **User function return inference v2.1**
   - forward predeclare теперь сохраняет obvious scalar return shape для literals, ternary, `if`, `switch`;
   - numeric branch union `int|float` сводится к `float`;
   - tuple branch return shape мержится поэлементно, если arity совпадает.

## Тесты

- `python -S tools/run_tests_no_pytest.py` → `147 passed`.
- `schema-check` smoke на `01_ma_indicator.pine` → `parse_ok=true`, `schema.ok=true`.
- `builtin-coverage` smoke → `function_count=255`, `namespace_count=30`.

## Ограничения проверки

Полный corpus/quality CLI-прогон в этой среде был прерван внешней фоновой проверкой файлов под `/mnt/data`, которая запускала большое число normal-python stat helper процессов. Рабочая сборка была перенесена в `/tmp`; full stdlib test-runner зелёный, а v2.8.0 baseline corpus на 300 fixtures был зелёным до изменений.
