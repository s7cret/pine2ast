# Merge report v2.4.0

## База

За основу взят `pine2ast_interpipe_v2_3_0_bigblock`, потому что он содержит более широкий v2.x слой: CLI, corpus validator, quality gate, SARIF/diagnostic reports, semantic report, schema validator, benchmark tooling и 300 real-world fixtures.

## Что взято из `v1.18.0 hardening`

В релиз добавлены материалы, которые полезны для дальнейшего hardening без риска сломать рабочий v2.3 pipeline:

- исторические changelog-файлы `CHANGELOG_v1.*.md`;
- `VERIFICATION_SUMMARY.md`;
- legacy valid fixtures из `tests/fixtures/valid`.

Они помещены в отдельные директории:

```text
docs/legacy/v1_18/
tests/fixtures/legacy_v1_18_valid/
```

## Что не переносилось автоматически

Не переносились напрямую:

- `pine2ast/semantic/analyzer.py` из v1.18;
- `pine2ast/parser/parser.py` из v1.18;
- `pine2ast/ast/nodes.py` из v1.18;
- v1.18 hardening unit tests как активные тесты.

Причина: эти файлы конфликтуют с v2.3 AST/semantic contract. Например, v1.18 использует `ArrayLiteralExpr`, а v2.3 использует `TupleExpr` для `[...]` expression; v2.3 также имеет новые diagnostic codes и extractor/reporting behavior.

## Проверочный вывод

- Чистый v2.3 baseline: зелёный stdlib runner, 120 тестов.
- Механическое добавление v1.18 hardening tests поверх v2.3 выявляет несхождение semantic behavior.
- Механическая замена ядра v2.3 на v1.18 ломает часть v2.x bigblock tests.

Итог: v2.4 фиксирует безопасную точку интеграции и формализует остаток работ в ТЗ 1.2.
