# Verification Summary — v1.18.0

```text
compileall: OK
tools/run_tests_no_pytest.py: 124 passed
CLI validate tests/fixtures/valid/v118_tuple_destructuring.pine: OK
zip integrity: OK
```

New v1.18 regression areas:

- tuple-returning builtins define typed targets
- non-tuple destructuring reports `P2A1411`
- wrong destructuring arity reports `P2A1410`
- user function tuple returns drive target types
- request.security tuple expressions preserve element types
