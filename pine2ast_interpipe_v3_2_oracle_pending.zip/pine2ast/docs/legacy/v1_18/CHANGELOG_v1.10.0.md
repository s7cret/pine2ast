# pine2ast Interpipe v1.10.0 Hardening

## Added

- `P2A1605 UNKNOWN_TYPE` for unknown explicit type references in:
  - variable declarations;
  - function/method parameters;
  - UDT fields;
  - nested generic type arguments.
- `P2A1606 DUPLICATE_FIELD` for duplicated UDT field names.
- `P2A1607 DUPLICATE_ENUM_MEMBER` for duplicated enum member names.
- Fixture `tests/fixtures/valid/v110_type_hardening.pine`.
- Regression suite `tests/unit/test_hardening_v1_10.py`.

## Verified

- `compileall` succeeds for package sources.
- Stdlib unit runner executed 69/69 tests successfully.
- Valid fixture corpus: 7/7 clean.
- CLI parse writes JSON AST for `v110_type_hardening.pine`.
