# Changelog — v1.13.0

## Added

- `P2A1210 TYPE_MISMATCH` diagnostic.
- Generic constructor type inference for:
  - `array.new<T>()`
  - `array.from(...)`
  - `matrix.new<T>()`
  - `map.new<K,V>()`
- Explicit type compatibility checks for:
  - typed variable declarations
  - UDT field defaults
  - function and method parameter defaults
- Regression tests for inferred array/matrix/map types and explicit mismatch diagnostics.
- Valid fixture `tests/fixtures/valid/v113_generic_type_inference.pine`.

## Fixed

- `xs = array.new<float>(); xs.nope(...)` no longer passes silently as an unknown-typed variable.
- `int x = "bad"`, `array<float> xs = array.new<int>()`, UDT field default mismatches and typed parameter default mismatches now report semantic errors.
- `float x = 1` remains accepted as safe numeric widening.

## Verification

- `compileall`: OK
- stdlib test runner: 95 passed
- valid fixtures: 10/10 clean
- zip integrity: OK
