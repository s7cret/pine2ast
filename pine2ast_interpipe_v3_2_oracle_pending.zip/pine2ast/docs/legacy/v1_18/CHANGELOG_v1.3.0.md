# pine2ast Interpipe v1.3.0 changelog

## Parser

- `na(x)` now parses as a builtin predicate call with an `Identifier("na")` callee.
- Bare `na` remains a Pine literal.

## Semantic analyzer

- Declaration calls in local blocks now emit `P2A1003 DECLARATION_NOT_GLOBAL`.
- Declaration statement nodes are walked without duplicate global-only diagnostics.
- Common real-world Pine calls using drawing, collection, string, color, ticker and request helpers produce fewer false `UNKNOWN_FUNCTION` diagnostics.

## Builtin registry

- Expanded to 253 functions.
- Expanded to 159 variables/constants.
- Expanded to 36 namespaces.
- Added common constants: `plot.style_*`, `location.*`, `shape.*`, `size.*`, `barmerge.*`, `xloc.*`, `yloc.*`, `extend.*`, line/label style constants, format/scale/currency/session/day/month constants.

## Tests

- Added v1.3 regression tests for `na()`, common enum constants, local declaration diagnostics, drawing objects and collection helpers.
- Stdlib-only test runner result: `28 passed`.
