# Changelog v1.17.0

## Return/value type hardening

- Fixed `MethodDeclaration` construction: multiline method bodies are now preserved as `Block` nodes instead of accidentally storing the `is_exported` flag as the body.
- Added analyzer-aware return type inference for user-defined functions.
- Added analyzer-aware return type inference for UDT methods, including receiver-field expressions such as `method getY(Pivot p) => p.y`.
- Added UDT field access type inference for typed assignments such as `float x = pivot.y` / `int x = pivot.y`.
- Added conditional branch type merging:
  - numeric branches widen safely, e.g. `close ? 1 : 2.5` -> `float`;
  - incompatible known branches expose `union<...>` and fail explicit typed assignments.
- Improved array literal inference: mixed numeric arrays such as `[1, 2.0]` now infer as `array<float>`; mixed incompatible arrays still reject explicit `array<T>` assignments.
- Corrected common strategy declaration registry types exposed by stronger member inference (`qty_type`, `format`, `strategy_commission`).

## Regression coverage

- Added valid fixture `tests/fixtures/valid/v117_return_and_field_types.pine`.
- Added regression suite `tests/unit/test_hardening_v1_17.py`.
- Version bumped to `0.1.17`.
