# pine2ast v1.11.0 hardening

- Added enum member validation for `Enum.UNKNOWN` access.
- Added UDT field validation for direct member access and reassignment.
- Added constructor arity / named-field validation for `Type.new(...)` calls.
- Improved for-in target semantics: duplicate targets are rejected and `_` is ignored as a discard target.
- Added v1.11 regression tests and a valid enum/UDT fixture.
