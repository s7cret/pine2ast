# v1.18.0 — tuple/destructuring hardening

## Added

- Typed tuple inference for tuple-returning builtins: `ta.macd`, `ta.bb`, `ta.kc`, `ta.dmi`, `ta.supertrend`, `ta.vwap`.
- Tuple-shape preservation for `request.security(..., [expr1, expr2, ...])`.
- Tuple returns from user-defined functions/methods using square-bracket return expressions.
- Semantic validation for tuple destructuring arity (`P2A1410`).
- Semantic validation for destructuring a non-tuple scalar (`P2A1411`).
- Typed destructuring targets, so follow-up assignments validate against the correct element type.
- Regression suite `tests/unit/test_hardening_v1_18.py`.
- Valid fixture `tests/fixtures/valid/v118_tuple_destructuring.pine`.

## Verification

- `compileall`: OK
- `tools/run_tests_no_pytest.py`: 124 passed
- `CLI validate v118_tuple_destructuring.pine`: OK
