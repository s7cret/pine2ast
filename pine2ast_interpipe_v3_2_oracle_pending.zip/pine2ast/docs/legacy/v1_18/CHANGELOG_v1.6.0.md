# pine2ast Interpipe v1.6.0 hardening

## Added

- Strict validation for explicit variable qualifiers: `const`/`simple`/`series` declarations now validate initializer qualifier compatibility.
- Negative history offsets such as `close[-1]` now report `P2A1303`.
- Builtin namespace/member validation for constants such as `color.*`, while preserving user UDT field access and imported library members.
- Additional `plot()` optional parameters: `offset`, `trackprice`, `histbase`, `join`, `editable`, `show_last`.
- Additional common constants/functions for `scale.*`, `session.*`, `currency.*`, `display.*`, `time*`, `dayof*`, `request.*`, and `timeframe.change`.
- v1.6 regression tests and a valid fixture covering plot options, request/time helpers and namespace constants.

## Fixed

- `plot(close, offset=1)` no longer raises an unknown-parameter diagnostic.
- Unknown builtin constants like `color.foobar` are now rejected.
- Invalid builtin scalar member access like `close.foo` is now rejected.
- Explicit `const x = close` now fails because the initializer is series-qualified.
