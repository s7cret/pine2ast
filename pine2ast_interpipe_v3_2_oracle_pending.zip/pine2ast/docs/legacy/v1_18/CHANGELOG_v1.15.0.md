# v1.15.0 hardening

- Validates user-defined function call signatures: unknown named parameters, missing required parameters, positional+named duplicates and typed argument mismatch.
- Validates UDT constructor field value types.
- Validates UDT method call typed arguments.
- Adds v1.15 regression tests and valid fixture.
