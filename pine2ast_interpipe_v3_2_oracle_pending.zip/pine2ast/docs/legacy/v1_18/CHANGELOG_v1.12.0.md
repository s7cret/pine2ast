# pine2ast v1.12.0 hardening

## Parser/Semantic hardening

- Added strict validation for user-defined type method calls:
  - `p.unknown()` on a known UDT variable is rejected with `P2A1608`.
  - Calling a UDT field as a function, e.g. `p.x()`, is rejected with `P2A1106`.
  - Declared receiver methods such as `method inc(Pivot p) => ...` are accepted via `p.inc()`.
- Added constructor default-field support:
  - UDT constructor calls may omit fields that have defaults in the type declaration.
  - Positional plus named duplicate constructor fields are rejected with `P2A1401`.
- Added typed method shorthand checks for collection variables:
  - `array<T>` / `matrix<T>` / `map<K,V>` variables accept known namespace methods, e.g. `xs.push(close)`.
  - Unknown collection method shorthands are rejected with `P2A1106`.
- Added scalar typed variable member-call validation:
  - `float x = close; x.foo()` no longer passes silently.
- Method definitions are now explicitly global-only and local method declarations emit `P2A1601`.
- Full generic type names are preserved for symbols, e.g. `array<float>`, enabling better semantic checks.

## Tests

- Added `tests/unit/test_hardening_v1_12.py`.
- Added valid fixture `tests/fixtures/valid/v112_method_constructor_hardening.pine`.
- Total stdlib runner coverage: 86 passed.
