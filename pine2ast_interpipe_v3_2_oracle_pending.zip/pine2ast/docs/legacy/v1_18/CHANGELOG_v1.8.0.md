# CHANGELOG v1.8.0

Hardening block focused on declaration signature coverage, UDT constructor/method semantics and mutable field reassignment.

## Added / fixed

- Fixed false redeclaration diagnostic for predeclared global methods.
- Allowed user-defined type constructors such as `Pivot.new(...)` without false `UNKNOWN_FUNCTION`.
- Allowed user-defined type method calls such as `p.isBullish()` without false unknown-call diagnostics.
- Allowed UDT field reassignment through mutable roots, e.g. `p.y := high`.
- Preserved const-root safety: `const P p = ...; p.y := ...` still reports `P2A1104`.
- Extended declaration signatures for common Pine v6 args:
  - `explicit_plot_zorder`
  - `max_lines_count`
  - `max_labels_count`
  - `max_boxes_count`
  - `max_polylines_count`
  - `dynamic_requests`
  - `format`
  - `precision`
- Extended strategy declaration args:
  - `initial_capital`, `currency`, `default_qty_type`, `default_qty_value`
  - `commission_type`, `commission_value`, `pyramiding`, `slippage`
  - `calc_on_order_fills`, `calc_on_every_tick`, `process_orders_on_close`
- Added more visual/table/label/line/box/polyline helpers and constants.
- Added v1.8 regression tests and `v18_udt_visual_declaration.pine` valid fixture.

## Verification

- `compileall`: OK
- stdlib unit runner: 58 tests, 0 failed
- valid fixtures: 5/5 clean
- invalid `strategy_when.pine`: confirms `P2A1501`
