# v1.18 → v2.6 porting matrix

Legacy hardening tests are copied into `tests/unit_legacy_v1_18/` as a non-blocking compatibility harness.
The active v2.x regression suite remains in `tests/unit/`.
Current count: `ported=66`, `obsolete=29`, `blocked=10`.

| File | Test | Status | Notes |
|---|---|---|---|
| `test_hardening_v1_10.py` | `test_unknown_type_in_variable_declaration_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_10.py` | `test_unknown_type_in_udt_field_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_10.py` | `test_unknown_type_in_function_parameter_is_rejected_once` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_10.py` | `test_duplicate_udt_fields_are_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_10.py` | `test_duplicate_enum_members_are_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_10.py` | `test_valid_recursive_user_types_and_generics_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_11.py` | `test_unknown_enum_member_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_11.py` | `test_known_enum_member_validates_cleanly` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_11.py` | `test_unknown_udt_field_access_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_11.py` | `test_unknown_udt_field_reassignment_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_11.py` | `test_udt_constructor_missing_required_field_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_11.py` | `test_udt_constructor_named_fields_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_11.py` | `test_duplicate_for_in_targets_are_rejected_but_underscore_is_ignored` | `blocked` | duplicate for-in target policy still needs dedicated diagnostic |
| `test_hardening_v1_11.py` | `test_for_in_underscore_target_does_not_leak_symbol` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_udt_unknown_method_call_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_udt_declared_method_call_validates_cleanly` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_udt_field_is_not_callable` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_udt_constructor_defaults_allow_omitted_fields` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_udt_constructor_duplicate_positional_and_named_field_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_method_declaration_inside_block_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_unknown_member_call_on_typed_scalar_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_known_array_method_shorthand_validates_cleanly` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_12.py` | `test_unknown_array_method_shorthand_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_generic_array_constructor_infers_type_for_member_validation` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_generic_array_constructor_allows_known_method_after_inference` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_13.py` | `test_array_from_infers_element_type_for_member_validation` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_explicit_scalar_type_mismatch_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_numeric_widening_int_to_float_is_allowed` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_explicit_generic_type_mismatch_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_udt_field_default_type_mismatch_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_function_parameter_default_type_mismatch_is_rejected` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_13.py` | `test_map_and_matrix_generic_constructor_inference` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_14.py` | `test_builtin_argument_type_mismatch_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_14.py` | `test_builtin_argument_type_match_still_passes` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_14.py` | `test_unary_not_requires_bool_operand` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_14.py` | `test_arithmetic_operator_rejects_string_operand_but_allows_string_concat` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_14.py` | `test_typed_variable_reassignment_type_mismatch` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_14.py` | `test_numeric_widening_still_allows_float_reassignment_from_int` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_14.py` | `test_udt_field_reassignment_type_mismatch` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_user_function_argument_type_mismatch_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_user_function_unknown_and_missing_named_arguments_are_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_user_function_positional_and_named_duplicate_parameter_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_udt_constructor_field_type_mismatch_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_udt_method_argument_type_mismatch_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_15.py` | `test_valid_user_function_constructor_and_method_calls_stay_clean` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_16.py` | `test_array_push_rejects_wrong_element_type` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_16.py` | `test_array_get_infers_element_type_for_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_16.py` | `test_map_put_key_and_value_types_are_checked` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_16.py` | `test_map_get_infers_value_type_for_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_16.py` | `test_matrix_set_and_get_use_element_type` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_multiline_method_body_is_preserved_as_block` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_user_function_return_type_is_used_for_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_udt_method_return_type_is_used_for_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_udt_field_access_type_is_used_for_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_conditional_branch_type_mismatch_is_visible_to_typed_assignment` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_mixed_numeric_array_literal_widens_to_array_float` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_17.py` | `test_mixed_non_numeric_array_literal_still_rejects_typed_array` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_18.py` | `test_tuple_builtins_define_typed_targets` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_18.py` | `test_tuple_destructuring_rejects_non_tuple_and_wrong_arity` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_18.py` | `test_user_function_tuple_return_drives_destructuring_types` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_18.py` | `test_request_security_tuple_expression_preserves_element_types` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_2.py` | `test_named_arg_keyword_series_parses` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_2.py` | `test_unknown_call_is_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_2.py` | `test_bad_indent_is_reported_by_layout` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_2.py` | `test_trivia_comments_are_preserved` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_2.py` | `test_common_registry_calls_parse_without_unknowns` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_3.py` | `test_na_call_is_identifier_not_literal_callee` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_3.py` | `test_common_plotshape_style_constants_and_request_barmerge_are_known` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_3.py` | `test_visual_declaration_call_inside_local_scope_is_diagnostic` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_3.py` | `test_user_typical_drawing_and_collections_parse_without_unknowns` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_4.py` | `test_import_before_declaration_is_preserved` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_4.py` | `test_request_security_tuple_expression_argument` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_4.py` | `test_mutable_var_reassignment_allowed_but_explicit_const_reassignment_rejected` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_4.py` | `test_array_literal_expression_in_call` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_4.py` | `test_duplicate_and_positional_after_named_still_reported` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_4.py` | `test_chart_point_and_drawing_registry_expansion` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_5.py` | `test_plot_title_requires_const_qualifier` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_5.py` | `test_hline_price_allows_input_but_rejects_series` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_5.py` | `test_too_many_positional_args_for_strict_signature` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_5.py` | `test_export_is_library_only` | `blocked` | library-only export policy remains semantic backlog |
| `test_hardening_v1_5.py` | `test_export_allowed_in_library` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_5.py` | `test_common_objects_and_alertcondition_validate` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_6.py` | `test_plot_extended_parameters_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_6.py` | `test_const_variable_rejects_series_initializer` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_6.py` | `test_const_variable_allows_literal_initializer` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_6.py` | `test_negative_history_offset_is_rejected` | `blocked` | negative constant history offset check remains backlog |
| `test_hardening_v1_6.py` | `test_unknown_builtin_namespace_member_is_rejected` | `blocked` | namespace-member strictness risks false positives on incomplete registry |
| `test_hardening_v1_6.py` | `test_builtin_scalar_member_access_is_rejected_but_udt_field_is_allowed` | `blocked` | scalar non-call member-access strictness remains separate from method-call strictness |
| `test_hardening_v1_6.py` | `test_common_time_request_and_session_constants_validate` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_7.py` | `test_local_symbols_do_not_leak_out_of_blocks` | `blocked` | scope-leak tests need exact legacy contract adaptation |
| `test_hardening_v1_7.py` | `test_local_shadowing_does_not_destroy_global_symbol` | `blocked` | shadowing behavior needs dedicated symbol-table regression |
| `test_hardening_v1_7.py` | `test_function_and_type_forward_references_are_resolved` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_7.py` | `test_common_strategy_risk_and_order_functions_validate` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_7.py` | `test_common_array_matrix_map_helpers_validate` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_7.py` | `test_common_ta_and_ticker_helpers_validate` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_8.py` | `test_udt_constructor_and_method_call_do_not_redeclare_or_unknown` | `obsolete` | covered by newer v2.x fixture/corpus policy or not useful as a standalone blocking check |
| `test_hardening_v1_8.py` | `test_udt_field_reassignment_is_allowed_but_const_root_is_rejected` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_8.py` | `test_declaration_common_v6_args_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_8.py` | `test_strategy_declaration_common_properties_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_8.py` | `test_common_plot_and_visual_helpers_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
| `test_hardening_v1_9.py` | `test_strategy_namespace_calls_are_strategy_only` | `blocked` | strategy-only namespace policy remains backlog |
| `test_hardening_v1_9.py` | `test_strategy_namespace_calls_allowed_in_strategy_scripts` | `blocked` | strategy script-type aware validator remains backlog |
| `test_hardening_v1_9.py` | `test_alertcondition_is_global_only_and_forbidden_in_local_blocks` | `ported` | semantic equivalent covered by active v2.x/v2.6 tests |
| `test_hardening_v1_9.py` | `test_for_in_destructuring_accepts_more_than_two_targets` | `blocked` | Pine for-in destructuring target arity policy needs doc verification |
| `test_hardening_v1_9.py` | `test_strategy_trade_collection_helpers_validate_cleanly` | `obsolete` | positive/clean behavior is covered by newer v2.x corpus, schema, and quality tests |
