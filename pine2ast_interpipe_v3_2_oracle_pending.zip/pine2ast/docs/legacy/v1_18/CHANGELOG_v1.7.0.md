# CHANGELOG v1.7.0

## Fixed

- Fixed semantic scope leakage for local declarations.
- Fixed local shadowing over global symbols.
- Reduced false `UNKNOWN_FUNCTION` diagnostics via a global predeclaration pass.

## Added

- Added v1.7 regression tests.
- Added `tests/fixtures/valid/v17_strategy_helpers.pine`.
- Expanded builtin registry to 433 functions, 207 variables/constants and 50 namespaces.

## Verified

- 53 stdlib-runner tests pass.
- All valid fixtures parse cleanly.
- Invalid `strategy_when.pine` still reports `P2A1501`.
