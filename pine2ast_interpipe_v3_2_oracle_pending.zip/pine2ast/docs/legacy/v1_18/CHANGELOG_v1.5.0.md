# pine2ast v1.5.0 hardening

## Added

- Qualifier-aware call signature validation from builtin metadata.
- Positional argument overflow validation for non-vararg signatures.
- `P2A1604 EXPORT_NOT_LIBRARY` diagnostic.
- Regression tests in `tests/unit/test_hardening_v1_5.py`.
- Additional common Pine v6 builtins/constants in `builtins_v6.json`.

## Fixed

- Input-qualified variables can now satisfy parameters whose maximum qualifier is `input`.
- Const enum-style values such as `format.price`, `display.all`, `strategy.long`, `barmerge.*` are treated as const-compatible where present in the registry.

## Verified

- `compileall`: OK
- stdlib test runner: 40 passed
- CLI parse/validate smoke checks: OK
