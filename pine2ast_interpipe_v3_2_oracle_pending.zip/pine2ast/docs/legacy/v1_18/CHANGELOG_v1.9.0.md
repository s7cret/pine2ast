# CHANGELOG v1.9.0

## Added

- Added script-scope validation for strategy runtime/order functions. Calls such as `strategy.entry()` now report `P2A1504` outside `strategy()` scripts.
- Added `P2A1504 SCRIPT_SCOPE_MISMATCH` diagnostic code.
- Added strategy trade collection helpers: `strategy.opentrades.*` and `strategy.closedtrades.*` function/variable metadata.
- Added parser support for destructuring `for [a, b, c, ...] in iterable` targets, not only two names.
- Added valid fixture `v19_strategy_scope_and_trades.pine`.
- Added v1.9 regression tests for strategy-only calls, local `alertcondition()`, multi-target for-in destructuring and trade collection helpers.

## Changed

- Semantic analyzer now honors `script_types` metadata in builtin signatures.
- Semantic analyzer treats builtin entries with `scope: global` the same as `global_only` for local-block diagnostics.
- Builtin registry snapshot: 443 functions, 215 variables/constants, 54 namespaces.

## Verified

```text
compileall: OK
stdlib unit runner: 63 passed
valid fixtures: 6/6 clean
zip integrity: OK
```
