# pine2ast v1.4.0 hardening

## Parser
- Preserves leading `import ...` statements before the `indicator()/strategy()/library()` declaration.
- Adds `ArrayLiteralExpr` for expression-list literals such as `[high, low]`.
- Supports tuple/list expressions inside call arguments, including `request.security(..., [high, low])`.
- Keeps keyword-like named arguments and generic calls compatible with v1.3 hardening.

## Semantic
- Fixes mutability: variables declared with `var` or ordinary declarations may be reassigned with `:=`.
- Keeps explicit `const` bindings protected from reassignment.
- Visits array literal elements for type/semantic diagnostics.
- Retains duplicate named argument and positional-after-named validation.

## Tests
- Added v1.4 regression tests for leading imports, request tuple expressions, mutable reassignment, explicit const rejection, and array literal calls.

- Expanded drawing/chart registry coverage to 330 functions, 174 variables/constants, and 43 namespaces.
