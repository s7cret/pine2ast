# Changelog v1.16.0

## Collection generic hardening

- Added generic-aware return type inference for collection shorthand calls:
  - `array<T>.get()/first()/last()/pop()/shift()/remove()` -> `T`
  - `matrix<T>.get()/max()/min()/avg()/median()/mode()` -> `T`
  - `map<K,V>.get()` -> `V`
  - `map<K,V>.keys()` -> `array<K>`
  - `map<K,V>.values()` -> `array<V>`
- Added semantic validation for collection element/key/value arguments:
  - `array<float>.push("bad")` -> `P2A1210`
  - `array<float>.set(0, "bad")` -> `P2A1210`
  - `map<string,float>.put("a", "bad")` -> `P2A1210`
  - `map<string,float>.get(1)` -> `P2A1210`
  - `matrix<float>.set(0, 0, "bad")` -> `P2A1210`
- Added valid fixture `v116_collection_generics.pine`.
- Added regression suite `test_hardening_v1_16.py`.
- Version bumped to `0.1.16`.
