# Current limitations for v3.2 RC

Release scope: `v3.2` / package `0.3.2rc1` / archive suffix `oracle_pending`.

## External TradingView oracle

TradingView Pine Editor access is not available from this environment. The compile-oracle report therefore remains `pending_external_oracle`; no pass/fail TradingView result is fabricated.

Use RC mode for local release packaging:

```bash
bash scripts/release_gate.sh --allow-pending-oracle
```

Use strict mode only after manual/authenticated Pine Editor evidence has been written into `tests/fixtures/compile_oracle`:

```bash
bash scripts/release_gate.sh
```

## Builtin policy

- `box.copy` and `label.copy` are modeled as supported Pine v6 builtins.
- `request.economic` is intentionally deferred pending an exact signature/return contract; semantic analysis emits `P2A1507` as an INFO diagnostic instead of pretending support.
- `runtime.error` is intentionally unsupported in this parser/semantic layer; semantic analysis emits `P2A1507` as an ERROR diagnostic.

`pine2ast builtin-coverage` keeps these categories separate: `official_unmapped_count` must be zero, while deferred/unsupported surfaces remain visible in their own counters.

## AST/schema compatibility

AST schema remains unchanged. Pine history references continue to use `HistoryRefExpr`; this release does not introduce array-index AST semantics or brace-based Pine blocks.
