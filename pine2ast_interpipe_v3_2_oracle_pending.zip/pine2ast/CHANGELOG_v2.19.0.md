# Changelog v2.19.0

Release focus: Builtin Registry Official Coverage and Compatibility Layer.

## Added

- Strengthened strict validation for `builtins_v6.json`:
  - validates `schema_version`/`pine_version`, required function fields, namespace/type/variable shapes, supported function keys, return/parameter type references, qualifier bounds, removed/deprecated version markers, and overload shape when present;
  - rejects duplicate parameter names and duplicate overload signatures.
- Added damaged-registry regression tests for missing schema version, bad Pine version, missing returns, unnamed parameters, invalid `removed_in`, duplicate overload/parameter, unknown qualifier, and unsupported type references.
- Expanded builtin metadata for common drawing/table compatibility calls:
  - `label.set_size`, `label.set_style`, `label.set_tooltip`, plus typed label setter backfills;
  - `box.set_border_*`, `box.set_extend`, `box.set_text*`, and typed box setter backfills;
  - `table.cell`, `table.cell_set_*`, and `table.merge_cells` named/type-aware metadata.
- Added signature validation tests covering named-argument, count, type, qualifier, and strict builtin namespace behavior.

## Changed

- Coverage taxonomy remains explicit: `internal_expected` is the project confidence set; `official_unmapped`, `known_deferred`, and `known_unsupported` remain honest non-completeness buckets.
- Documented that current `any`/`unknown` registry returns are compatibility placeholders pending official signature mapping, not claims of complete TradingView coverage.

## Oracle status

TradingView Pine Editor compile-oracle access was not available in this environment. This release remains `pending_external_oracle` and the archive is named with `_oracle_pending`.
