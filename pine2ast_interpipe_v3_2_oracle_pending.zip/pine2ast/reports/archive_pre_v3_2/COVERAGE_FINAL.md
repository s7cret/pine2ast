# Coverage final

```text
Name                                    Stmts   Miss Branch BrPart  Cover   Missing
-----------------------------------------------------------------------------------
pine2ast/__init__.py                        4      0      0      0   100%
pine2ast/api.py                            97     10     24      7    86%   74-77, 79-82, 87, 92-95, 97, 114->125, 137, 142
pine2ast/ast/__init__.py                    5      0      0      0   100%
pine2ast/ast/base.py                       37      2     16      2    92%   48, 50
pine2ast/ast/nodes.py                     217      0      0      0   100%
pine2ast/ast/schema.py                     55      8     14      6    80%   19, 76, 85, 94, 107-115, 120, 126
pine2ast/ast/serialize.py                   7      0      0      0   100%
pine2ast/ast/types.py                       9      0      0      0   100%
pine2ast/ast/visitors.py                   16      1     12      1    93%   12
pine2ast/config.py                          3      0      0      0   100%
pine2ast/corpus.py                         28      0     10      1    97%   18->17
pine2ast/diagnostics/__init__.py            6      0      0      0   100%
pine2ast/diagnostics/codes.py              56      0      0      0   100%
pine2ast/diagnostics/diagnostic.py         27      0      4      0   100%
pine2ast/diagnostics/formatter.py          10      0      4      0   100%
pine2ast/diagnostics/reports.py            57      1     12      1    97%   101
pine2ast/layout/__init__.py                 2      0      0      0   100%
pine2ast/layout/processor.py              108      3     56      5    95%   76->85, 86, 132->134, 165, 186
pine2ast/lexer/__init__.py                  3      0      0      0   100%
pine2ast/lexer/annotations.py              47      0      8      0   100%
pine2ast/lexer/lexer.py                   188     14     76      7    91%   84->89, 149->156, 192, 194-200, 206-212, 228, 246-247
pine2ast/lexer/token.py                   100      2      0      0    98%   136, 149
pine2ast/parser/__init__.py                 2      0      0      0   100%
pine2ast/parser/parser.py                 666     42    300     44    91%   112, 125->128, 133, 138, 161->163, 166, 176->178, 221, 249->255, 272, 299->306, 305, 317-319, 328, 333, 362->364, 416->423, 476, 500->518, 506-513, 517, 606, 608, 614-621, 632->638, 637, 670->676, 683, 686->692, 691, 717, 719, 758, 762, 770, 775, 784, 803-805, 809->808, 812-813, 823->818, 865-873, 903, 918->920, 923->exit
pine2ast/parser/precedence.py               2      0      0      0   100%
pine2ast/quality.py                        70      1     10      2    96%   86, 90->89
pine2ast/semantic/__init__.py               7      0      0      0   100%
pine2ast/semantic/analyzer.py            1156    112    726     92    88%   121->118, 129->118, 135->118, 138->118, 141->143, 193, 274->273, 304-310, 319->340, 326, 430, 445->447, 460, 476->478, 479->487, 488->490, 494->501, 502, 517->519, 524, 529, 564, 592->exit, 598, 602-606, 618, 624, 647-659, 661-668, 674, 679-687, 753, 862->exit, 944, 948, 964, 1175, 1215, 1264, 1273, 1285-1286, 1291-1294, 1302, 1304, 1309->1311, 1336, 1338, 1343->1345, 1349, 1379, 1394, 1396, 1398, 1400, 1417, 1431, 1437, 1460-1463, 1465-1468, 1508, 1515, 1522-1528, 1561, 1565, 1568, 1579, 1586, 1602->1601, 1618-1626, 1647, 1652, 1671, 1687, 1692->1694, 1714-1720, 1721->exit, 1810, 1905, 1916->1927, 1940, 1944, 1964, 1980, 1990, 1997, 2005, 2037, 2041->2038, 2059, 2089, 2098->2086, 2106, 2114->exit
pine2ast/semantic/builtin_registry.py     217     16    100     17    90%   116, 142, 147, 155, 167, 175, 218, 238, 248, 251, 253, 256, 262, 264->233, 269, 273, 275
pine2ast/semantic/extractors.py           144     14     52      7    87%   47, 61, 229-230, 234-235, 237-238, 242-248
pine2ast/semantic/qualifier_infer.py       71     10     48      5    82%   30, 58->60, 61-62, 63->65, 90-96
pine2ast/semantic/reports.py               42      1      8      1    96%   39
pine2ast/semantic/scopes.py                18      0      0      0   100%
pine2ast/semantic/symbols.py               23      0      0      0   100%
pine2ast/semantic/type_infer.py           215     20    142     16    88%   37, 54, 63->67, 68-70, 93, 95, 100->102, 114, 124, 190, 205, 242->244, 245-246, 247->249, 299-305
pine2ast/source/__init__.py                 2      0      0      0   100%
pine2ast/source/normalizer.py              31      0      8      0   100%
pine2ast/testing/__init__.py                2      0      0      0   100%
pine2ast/testing/ast_compare.py             7      0      4      0   100%
pine2ast/testing/compile_oracle.py        100      5     14      5    91%   80, 112-125, 137, 139, 140->143
pine2ast/testing/golden.py                 78      5     20      5    90%   94, 116, 139, 148, 153
-----------------------------------------------------------------------------------
TOTAL                                    3935    267   1668    224    90%
Coverage XML written to file coverage.xml
Required test coverage of 90.0% reached. Total coverage: 90.34%
250 passed in 8.16s
```
