# FINAL AUDIT v3.1 RC oracle-pending

Release id: `v3.1` / package version `0.3.1rc1` / archive suffix `oracle_pending`.

## Local gates

The release gate writes reproducible logs under `reports/final/`:

- `RUFF_FINAL.log`
- `BLACK_FINAL.log`
- `MYPY_FINAL.log`
- `TEST_RUN_FINAL.log`
- `QUALITY_GATE_FINAL.json` + `QUALITY_GATE_FINAL.log`
- `BUILTIN_COVERAGE_FINAL.json` + `BUILTIN_COVERAGE_FINAL.log`
- `COMPILE_ORACLE_FINAL.json` + `COMPILE_ORACLE_FINAL.log`

Command:

```bash
bash scripts/release_gate.sh --allow-pending-oracle
```

## External oracle gate

TradingView Pine Editor access is unavailable in this environment. The oracle gate is therefore allowed only in explicit RC mode and remains `pending_external_oracle`. Strict mode (`bash scripts/release_gate.sh`) is expected to fail until real external oracle evidence replaces pending metadata.

## Release artifact gate

The release archive is built with `tools/build_release_zip.py` and validated with:

```bash
.venv/bin/python tools/check_release_manifest.py RELEASE_MANIFEST_v3_1_oracle_pending.json
```

No TradingView result was fabricated. AST schema compatibility is preserved.
