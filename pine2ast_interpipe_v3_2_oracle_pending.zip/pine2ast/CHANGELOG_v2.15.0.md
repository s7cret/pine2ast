# Pine2AST v2.15.0 — P0 Golden/negative fixtures hardening

Дата: 2026-04-27

## Что закрыто

- Расширен curated-набор валидных fixtures до production-sized уровня: 57 `.pine` файлов.
- Добавлены категории валидных fixtures: declarations, imports, types, expressions, layout, semantic_ok, loops, strings, optimizer_contract, collections, real_world_smoke.
- Добавлены 23 invalid fixtures, включая обязательные negative-cases из исходного ТЗ 1.1:
  - `{}` для enum/type;
  - `input int ...` как невалидный declaration qualifier;
  - non-bool condition;
  - `bool = na`;
  - history reference на literal;
  - repeated history reference;
  - `:=` / compound assignment для undeclared;
  - `strategy.entry(..., when=...)` для Pine v6;
  - nested function;
  - `break` outside loop;
  - missing/duplicate declaration statement;
  - duplicate named args и positional-after-named.
- Для всех curated valid fixtures сгенерированы golden AST и diagnostics JSON.
- Для всех invalid fixtures добавлены `.diagnostics.json` контракты с `expected_codes`.
- Добавлены integration tests:
  - `test_golden_ast_contract.py`;
  - `test_invalid_diagnostics_contract.py`.
- Усилен `pine2ast.testing.golden`:
  - exact/ignore-spans AST compare;
  - exact diagnostics compare;
  - invalid diagnostic-code contract validation.
- Добавлен evidence-report `GOLDEN_FIXTURE_REPORT_v2_15_0.json`.

## Проверки в sandbox

- `TEST_INTEGRATION_v2_15_0.log`: 8 integration checks passed.
- Curated valid parse smoke: 57/57 ok.
- Invalid diagnostic contracts: 23/23 имеют `.diagnostics.json`.

## Ограничения

- Внешний TradingView compile-oracle не закрывался в этом блоке и остаётся следующим P0 этапом.
- `pytest/ruff/black/mypy` требуют нормального dev-env из CI; sandbox использует `python -S` из-за локальной проблемы sitecustomize окружения.
