# Changelog v2.7.0

## База

Релиз собран поверх `pine2ast_interpipe_v2_6_0` с сохранением публичного v2.x API и AST schema `1.0`.

## Реализовано

- Добавлены активные hardening tests `tests/unit/test_bigblock_v2_7.py`.
- Scope/shadowing hardening:
  - локальные объявления больше не резолвятся после выхода из local block;
  - локальный shadowing больше не перетирает глобальный symbol в `SemanticModel.symbols`;
  - compatibility сохранён: локальные/loop symbols остаются в `SemanticModel.symbols` для introspection старых v2.x тестов, но `_resolve()` игнорирует out-of-scope locals.
- For-in policy:
  - duplicate for-in targets диагностируются через `P2A1102 REDECLARATION`;
  - `_` игнорируется при проверке duplicate targets;
  - добавлен diagnostic code `P2A1902 FOR_IN_TARGET_ARITY` для будущей parser/semantic arity-политики.
- Export/library policy:
  - `export` теперь разрешён только в `library()` scripts;
  - новый diagnostic code `P2A1901 EXPORT_NOT_LIBRARY`.
- History-reference hardening:
  - статический отрицательный offset вроде `close[-1]` диагностируется;
  - новый diagnostic code `P2A1305 HISTORY_NEGATIVE_OFFSET`.
- Strategy script-type validation:
  - order/risk calls `strategy.entry/exit/close/order/cancel/...` теперь требуют `strategy()` script;
  - новый diagnostic code `P2A1504 STRATEGY_CALL_WRONG_SCRIPT_TYPE`;
  - strategy constants/state variables не запрещались, чтобы не ломать helper/inspection code до расширения registry.

## Проверки

See `TEST_RUN_v2_7_0.log`.

Summary:

```text
python -S tools/run_tests_no_pytest.py
→ 138 passed

pine2ast validate-corpus tests/fixtures/real_world
→ file_count=300, ok_count=300, error_count=0

pine2ast quality-gate tests/fixtures/real_world
→ ok=true, file_count=300, error_count=0, warning_count=1

pine2ast schema-check tests/fixtures/real_world/01_ma_indicator.pine
→ parse_ok=true, schema.ok=true
```

## Не делалось

- Strict unknown namespace member diagnostics remain deferred until builtin registry coverage is broader.
- Deep import resolution remains deferred.
- External library body/cache/lockfile support remains deferred.
