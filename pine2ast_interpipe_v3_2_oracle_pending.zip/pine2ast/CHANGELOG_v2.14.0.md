# Pine2AST v2.14.0 — P0 Quality/CI/Coverage Gate

## Added

- GitHub Actions CI workflow with Python 3.10/3.11/3.12 matrix.
- `tools/run_quality_gate.py` release wrapper for tests, optional dev tools, real-world corpus quality gate and builtin registry coverage.
- `pyproject.toml` configuration for pytest, coverage, ruff, black and mypy.
- Coverage and mypy baseline documentation artifacts.

## Changed

- Package version bumped to `0.2.14`.
- README now documents the release quality command sequence.

## Verification in this sandbox

- Stdlib runner: `175 passed`.
- Existing v2.13 real-world quality and builtin coverage reports were carried forward as v2.14 evidence because parser/semantic production code was not changed in this block.
- `pytest-cov`, `ruff`, `black` and `mypy` are not installed in this sandbox; CI is configured to run them in a normal dev environment.
