# Pine2AST Interpipe v2.8.0

Дата: 2026-04-27

База: `pine2ast_interpipe_v2_7_0`

## Что сделано

1. Parser-level recovery для malformed `for [a, b, c] in ...`:
   - parser больше не зацикливается и не разваливает body;
   - сохраняет target names в AST;
   - выдаёт `P2A1902 FOR_IN_TARGET_ARITY` уже на parser-level;
   - semantic-layer check оставлен как дополнительная защита.
2. Strategy namespace policy v2:
   - order/risk calls по-прежнему требуют `strategy()`;
   - strategy state variables (`strategy.equity`, `strategy.position_size`, etc.) требуют `strategy()` и диагностируются через `P2A1505`;
   - constants (`strategy.long`, `strategy.short`, `strategy.cash`, `strategy.percent_of_equity`) разрешены в library/indicator contexts, чтобы не ломать helper-библиотеки;
   - `strategy.closedtrades.*` / `strategy.opentrades.*` добавлены как read-only accessors в builtin registry.
3. Namespace strictness soft-mode:
   - неизвестные members известных builtin namespaces теперь дают `INFO P2A1506 UNKNOWN_BUILTIN_MEMBER`;
   - `request.*` оставлен error-path через `P2A1502`, потому что это data-access namespace.
4. Forward tuple return shape:
   - global predeclare теперь сохраняет tuple arity для forward calls к функциям с tuple-return body;
   - exact return type уточняется после прохода по body.
5. Добавлены active tests: `tests/unit/test_bigblock_v2_8.py`.
6. Расширен `builtins_v6.json` common accessors для `strategy.closedtrades.*` и `strategy.opentrades.*`.

## Проверки

```text
python -S tools/run_tests_no_pytest.py
→ 143 passed

validate-corpus tests/fixtures/real_world
→ file_count=300, ok_count=300, error_count=0

quality-gate tests/fixtures/real_world
→ ok=true, file_count=300, ok_count=300, error_count=0, warning_count=1, info_count=1

schema-check tests/fixtures/real_world/01_ma_indicator.pine
→ parse_ok=true, schema.ok=true
```

## Совместимость

- Public API не менялся.
- AST schema не менялась.
- Новый `P2A1506` имеет severity `INFO`, чтобы не ломать quality gate на неполной registry.
